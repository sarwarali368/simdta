# WEBSITE CODE EXTRACTIONS REPORT 

Website: https://kami-database.vercel.app/index.html
EXTRACTION DATE: 1820113.660693923

## Summary:
- HTML FILES: 1
- CSS FILES: 0
- INLINE CSS BLOCKS: 1
- JAVASCRIPT FILES: 2
- INLINE JAVASCRIPT BLOCKS: 1
- API ENDPOINTS FOUND: 0
- IMAGES FOUND: 8

## Files Structure:
- index.html (Main HTML file)
- css/ (All CSS files)
- js/ (All JavaScript files)
- api_endpoints.txt (List of found API endpoints)

## Note:
This extraction includes all publicly accessible code from the website.
Some dynamic content loaded via AJAX may not be included.
